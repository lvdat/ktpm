<?
include $_SERVER['DOCUMENT_ROOT'].'/inc/foot.php';
echo '<!-- Admin page -->';